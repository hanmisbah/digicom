import AsyncStorage from '@react-native-async-storage/async-storage';
import RNFS from 'react-native-fs';
import { uploadImage } from '../api';
import NetInfo from '@react-native-community/netinfo';

// Storage Key
const OFFLINE_IMAGES_KEY = 'offline_images';

// ✅ Save image locally when offline
export const saveImageOffline = async (imageUri, containerNumber) => {
    try {
        const fileName = imageUri.split('/').pop();
        const destPath = `${RNFS.DocumentDirectoryPath}/${fileName}`;

        // Copy image to local storage
        await RNFS.copyFile(imageUri, destPath);

        // Store metadata in AsyncStorage
        let storedImages = await AsyncStorage.getItem(OFFLINE_IMAGES_KEY);
        storedImages = storedImages ? JSON.parse(storedImages) : [];

        storedImages.push({ uri: destPath, containerNumber });
        await AsyncStorage.setItem(OFFLINE_IMAGES_KEY, JSON.stringify(storedImages));

        console.log("✅ Image saved offline:", destPath);
    } catch (error) {
        console.error("❌ Error saving image offline:", error);
    }
};

// ✅ Retrieve stored images
export const getOfflineImages = async () => {
    try {
        let storedImages = await AsyncStorage.getItem(OFFLINE_IMAGES_KEY);
        return storedImages ? JSON.parse(storedImages) : [];
    } catch (error) {
        console.error("❌ Error retrieving offline images:", error);
        return [];
    }
};

// ✅ Upload all stored images when online
export const uploadPendingImages = async (token) => {
    try {
        const storedImages = await getOfflineImages();

        if (storedImages.length === 0) {
            console.log("📂 No offline images to upload.");
            return;
        }

        console.log(`📤 Uploading ${storedImages.length} pending images...`);

        for (const img of storedImages) {
            const formData = new FormData();
            formData.append('image', {
                uri: img.uri,
                type: 'image/jpeg',
                name: img.uri.split('/').pop(),
            });
            formData.append('container', img.containerNumber);

            await uploadImage(formData, token);  // Upload to server
        }

        await AsyncStorage.removeItem(OFFLINE_IMAGES_KEY);  // Clear storage
        console.log("✅ All pending images uploaded successfully!");
    } catch (error) {
        console.error("❌ Error uploading pending images:", error);
    }
};
