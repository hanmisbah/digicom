import NetInfo from '@react-native-community/netinfo';

// Check network status
export const checkInternetConnection = async () => {
    const state = await NetInfo.fetch();
    return state.isConnected;
};
