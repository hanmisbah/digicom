import RNFS from 'react-native-fs';
import { Alert } from 'react-native';

export const checkStorageLimit = async () => {
  try {
    const fsInfo = await RNFS.getFSInfo();
    // fsInfo.freeSpace is in bytes.
    // Define a threshold—for example, 100 MB (100 * 1024 * 1024 bytes).
    const threshold = 100 * 1024 * 1024; 
    if (fsInfo.freeSpace < threshold) {
      Alert.alert("Storage Warning", "Your device storage is running low. Please free up some space.");
      return false;  // Indicate that storage is low
    }
    return true;  // Storage is sufficient
  } catch (error) {
    console.error("Error checking storage info:", error);
    return true; // If error, assume storage is fine to avoid blocking the user.
  }
};
