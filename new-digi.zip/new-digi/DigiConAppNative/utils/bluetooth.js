import RNBluetoothClassic from 'react-native-bluetooth-classic';

// Scan for Bluetooth Devices
export const scanDevices = async () => {
    try {
        const devices = await RNBluetoothClassic.getBondedDevices();
        return devices;
    } catch (error) {
        console.error("Error scanning devices:", error);
        return [];
    }
};

// Connect to a Bluetooth Device
export const connectToDevice = async (deviceAddress) => {
    try {
        const connected = await RNBluetoothClassic.connectToDevice(deviceAddress);
        return connected;
    } catch (error) {
        console.error("Connection Error:", error);
        return false;
    }
};

// Send File via Bluetooth
export const sendFileViaBluetooth = async (deviceAddress, fileData) => {
    try {
        await RNBluetoothClassic.writeToDevice(deviceAddress, fileData);
        return true;
    } catch (error) {
        console.error("File Transfer Error:", error);
        return false;
    }
};
