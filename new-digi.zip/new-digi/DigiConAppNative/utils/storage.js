import AsyncStorage from '@react-native-async-storage/async-storage';

// Save data to local storage
export const saveData = async (key, value) => {
    try {
        await AsyncStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
        console.error("Error saving data:", error);
    }
};

// Retrieve data from local storage
export const getData = async (key) => {
    try {
        const value = await AsyncStorage.getItem(key);
        return value ? JSON.parse(value) : null;
    } catch (error) {
        console.error("Error retrieving data:", error);
    }
};

// Remove data from local storage
export const removeData = async (key) => {
    try {
        await AsyncStorage.removeItem(key);
    } catch (error) {
        console.error("Error removing data:", error);
    }
};
