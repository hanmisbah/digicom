import RNFS from 'react-native-fs';
import DocumentPicker from 'react-native-document-picker';
import Share from 'react-native-share';

// Pick an Image File
export const pickImage = async () => {
    try {
        const result = await DocumentPicker.pickSingle({ type: [DocumentPicker.types.images] });
        return result.uri;
    } catch (error) {
        console.error("Error picking image:", error);
        return null;
    }
};

// Convert Image to PDF
export const convertImageToPDF = async (imageUri) => {
    try {
        const pdfPath = `${RNFS.DocumentDirectoryPath}/converted.pdf`;
        // Logic for creating a PDF (Add library like `react-native-pdf-lib`)
        return pdfPath;
    } catch (error) {
        console.error("Error converting to PDF:", error);
        return null;
    }
};

// Share a File
export const shareFile = async (filePath) => {
    try {
        await Share.open({ url: `file://${filePath}`, type: 'application/pdf' });
    } catch (error) {
        console.error("Error sharing file:", error);
    }
};
