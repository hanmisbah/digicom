import RNBluetoothClassic from 'react-native-bluetooth-classic';
import DocumentPicker from 'react-native-document-picker';
import RNFS from 'react-native-fs';
import { Alert } from 'react-native';

// 📤 Send File via Bluetooth
export const sendFile = async (device) => {
    try {
        // Open File Picker
        const result = await DocumentPicker.pickSingle({
            type: [DocumentPicker.types.allFiles],
        });

        // Remove file:// prefix if present
        const fileUri = result.uri.replace("file://", "");
        const fileData = await RNFS.readFile(fileUri, 'base64'); // Read file as base64

        // Send file data via Bluetooth
        const response = await RNBluetoothClassic.writeToDevice(device.address, fileData);
        console.log("📁 File sent successfully:", response);

        Alert.alert("Success", "File sent successfully!");
    } catch (error) {
        if (DocumentPicker.isCancel(error)) {
            console.log("User cancelled file picker");
        } else {
            console.error("❌ Bluetooth File Transfer Error:", error);
            Alert.alert("Error", error.message);
        }
    }
};
