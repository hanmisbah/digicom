import 'react-native-gesture-handler';
import 'react-native-polyfill-globals/auto';
import React from 'react';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './screens/HomeScreen';
import LoginScreen from './screens/LoginScreen';
import SignupScreen from './screens/SignupScreen';
import BluetoothSenderScreen from './screens/BluetoothSenderScreen';
import BluetoothReceiverScreen from './screens/BluetoothReceiverScreen';
import FileSharingScreen from './screens/FileSharingScreen';
import ImageToPDFScreen from './screens/ImageToPDFScreen';
import ImageShareScreen from './screens/ImageShareScreen';

const Stack = createStackNavigator();

const App = () => {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Home">
          <Stack.Screen name="Home" component={HomeScreen} />
          <Stack.Screen name="Login" component={LoginScreen} />
          <Stack.Screen name="Signup" component={SignupScreen} />
          <Stack.Screen name="Bluetooth Sender" component={BluetoothSenderScreen} />
          <Stack.Screen name="Bluetooth Receiver" component={BluetoothReceiverScreen} />
          <Stack.Screen name="File Sharing" component={FileSharingScreen} />
          <Stack.Screen name="Image to PDF" component={ImageToPDFScreen} />
          <Stack.Screen name="ImageShare" component={ImageShareScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </GestureHandlerRootView>
  );
};

export default App;
;
