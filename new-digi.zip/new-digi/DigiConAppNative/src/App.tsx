import React, { useEffect } from 'react';
import { View, Text } from 'react-native';
import { signup, login } from './src/api';

const App = () => {
    useEffect(() => {
        const testApi = async () => {
            try {
                // Test Signup
                const userData = {
                    username: 'testuser',
                    password: 'password123',
                };
                const signupResponse = await signup(userData);
                console.log('Signup Success:', signupResponse);

                // Test Login
                const loginResponse = await login(userData);
                console.log('Login Success:', loginResponse);
            } catch (error) {
                console.error('API Test Error:', error);
            }
        };

        testApi();
    }, []);

    return (
        <View>
            <Text>Testing API Calls...</Text>
        </View>
    );
};

export default App;
