import AsyncStorage from '@react-native-async-storage/async-storage';
import RNFS from 'react-native-fs';
import { uploadImage } from '../api';  // Import the image upload function

// Key for storing offline images
const OFFLINE_IMAGES_KEY = 'offline_images';

/**
 * Save an image locally when offline.
 * @param {string} imageUri - The URI of the image.
 * @param {string} containerId - The container number to associate with the image.
 */
export const saveImageOffline = async (imageUri, containerId) => {
    try {
        const fileName = imageUri.split('/').pop(); // Extract filename
        const destPath = `${RNFS.DocumentDirectoryPath}/${fileName}`; // Local storage path

        await RNFS.copyFile(imageUri, destPath); // Copy file to local storage

        // Save metadata in AsyncStorage
        let storedImages = await AsyncStorage.getItem(OFFLINE_IMAGES_KEY);
        storedImages = storedImages ? JSON.parse(storedImages) : [];

        storedImages.push({ uri: destPath, containerId });
        await AsyncStorage.setItem(OFFLINE_IMAGES_KEY, JSON.stringify(storedImages));

        console.log("✅ Image saved offline:", destPath);
    } catch (error) {
        console.error("❌ Error saving image offline:", error);
    }
};

/**
 * Retrieve all offline stored images.
 * @returns {Promise<Array>} - Array of stored image data.
 */
export const getOfflineImages = async () => {
    try {
        let storedImages = await AsyncStorage.getItem(OFFLINE_IMAGES_KEY);
        return storedImages ? JSON.parse(storedImages) : [];
    } catch (error) {
        console.error("❌ Error retrieving offline images:", error);
        return [];
    }
};

/**
 * Upload all pending offline images when online.
 * @param {string} token - Authentication token for API requests.
 */
export const uploadPendingImages = async (token) => {
    try {
        let storedImages = await getOfflineImages();

        if (storedImages.length === 0) {
            console.log("📂 No offline images to upload.");
            return;
        }

        for (let image of storedImages) {
            const formData = new FormData();
            formData.append("image", {
                uri: image.uri,
                type: "image/jpeg",
                name: image.uri.split('/').pop(),
            });
            formData.append("container", image.containerId);

            // Try to upload
            await uploadImage(formData, token);
        }

        await clearOfflineImages(); // Clear the stored images after successful upload
        console.log("✅ All offline images uploaded!");
    } catch (error) {
        console.error("❌ Error uploading offline images:", error);
    }
};

/**
 * Clear all offline stored images after successful upload.
 */
export const clearOfflineImages = async () => {
    try {
        await AsyncStorage.removeItem(OFFLINE_IMAGES_KEY);
        console.log("✅ Offline images cleared!");
    } catch (error) {
        console.error("❌ Error clearing offline images:", error);
    }
};
