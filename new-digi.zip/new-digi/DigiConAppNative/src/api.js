import axios from 'axios';

// Backend Base URL
const BASE_URL = 'http://82.25.110.148:8000/api/';


// User Signup API
export const signup = async (userData) => {
    try {
        const response = await axios.post(`${BASE_URL}signup/`, userData);
        return response.data;
    } catch (error) {
        console.error('Signup Error:', error.response?.data || error.message);
        throw error;
    }
};

// User Login API
export const login = async (credentials) => {
    try {
        const response = await axios.post(`${BASE_URL}login/`, credentials);
        return response.data;
    } catch (error) {
        console.error('Login Error:', error.response?.data || error.message);
        throw error;
    }
};


// Image Upload API
export const uploadImage = async (imageData, token) => {
    try {
        const formData = new FormData();
        formData.append('image', {
            uri: imageData.uri,
            type: imageData.type,
            name: imageData.fileName || `photo_${Date.now()}.jpg`
        });

        const response = await axios.post(`${BASE_URL}upload-image/`, formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
                'Authorization': `Bearer ${token}`, // Include token for authentication
            },
        });

        return response.data;
    } catch (error) {
        console.error('Image Upload Error:', error.response?.data || error.message);
        throw error;
    }
};






