import React, { useState } from 'react';
import { View, Button, Image, Alert } from 'react-native';
import { launchCamera, launchImageLibrary } from 'react-native-image-picker';

const ImagePickerScreen = () => {
    const [imageUri, setImageUri] = useState(null);

    const pickImage = () => {
        launchImageLibrary({ mediaType: 'photo' }, (response) => {
            if (response.didCancel) {
                Alert.alert('Image selection canceled');
            } else if (response.errorMessage) {
                Alert.alert('Error:', response.errorMessage);
            } else {
                setImageUri(response.assets[0].uri);
            }
        });
    };

    const captureImage = () => {
        launchCamera({ mediaType: 'photo' }, (response) => {
            if (response.didCancel) {
                Alert.alert('Camera was closed');
            } else if (response.errorMessage) {
                Alert.alert('Error:', response.errorMessage);
            } else {
                setImageUri(response.assets[0].uri);
            }
        });
    };

    return (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            {imageUri && <Image source={{ uri: imageUri }} style={{ width: 200, height: 200, marginBottom: 10 }} />}
            <Button title="Pick Image from Gallery" onPress={pickImage} />
            <Button title="Capture Image with Camera" onPress={captureImage} />
        </View>
    );
};

export default ImagePickerScreen;
