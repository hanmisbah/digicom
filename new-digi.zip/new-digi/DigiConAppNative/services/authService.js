import axios from 'axios';

const API_URL = 'http://127.0.0.1:8000/api/'; // Update if Django backend runs on a different URL

// User Signup
export const signup = async (email, password) => {
  try {
    const response = await axios.post(`${API_URL}signup/`, {
      email: email,
      password: password
    });
    return response.data;
  } catch (error) {
    console.error('Signup error:', error.response?.data || error.message);
    throw error.response?.data || error.message;
  }
};

// User Login
export const login = async (email, password) => {
  try {
    const response = await axios.post(`${API_URL}login/`, {
      email: email,
      password: password
    });
    return response.data;
  } catch (error) {
    console.error('Login error:', error.response?.data || error.message);
    throw error.response?.data || error.message;
  }
};
