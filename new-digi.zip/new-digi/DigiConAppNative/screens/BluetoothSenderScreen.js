import React, { useState, useEffect } from 'react';
import {
  View, Text, Button, Alert, FlatList, TouchableOpacity,
  PermissionsAndroid, Platform
} from 'react-native';
import RNBluetoothClassic from 'react-native-bluetooth-classic';
import * as DocumentPicker from 'expo-document-picker';
import * as FileSystem from 'expo-file-system';

const BluetoothSenderScreen = () => {
  const [pairedDevices, setPairedDevices] = useState([]);
  const [connectedDevice, setConnectedDevice] = useState(null);

  // ✅ Request Bluetooth permissions for Android
  useEffect(() => {
    const requestBluetoothPermission = async () => {
      if (Platform.OS === 'android') {
        try {
          const permissions = [
            PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
            PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT
          ];

          if (Platform.Version >= 31) {
            permissions.push(PermissionsAndroid.PERMISSIONS.BLUETOOTH_ADVERTISE);
          }

          const granted = await PermissionsAndroid.requestMultiple(permissions);

          if (
            granted[PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN] !== PermissionsAndroid.RESULTS.GRANTED ||
            granted[PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT] !== PermissionsAndroid.RESULTS.GRANTED
          ) {
            Alert.alert("Permission Denied", "Bluetooth permissions are required.");
          }
        } catch (error) {
          console.error("Permission Error:", error);
        }
      }
    };

    requestBluetoothPermission();
  }, []);

  // ✅ Fetch paired Bluetooth devices
  useEffect(() => {
    const fetchDevices = async () => {
      try {
        const devices = await RNBluetoothClassic.getBondedDevices();
        setPairedDevices(devices);
      } catch (error) {
        Alert.alert("Error", "Failed to fetch paired devices: " + error.message);
      }
    };

    fetchDevices();
  }, []);

  // ✅ Connect to a selected device
  const connectToDevice = async (device) => {
    try {
      const connected = await RNBluetoothClassic.connectToDevice(device.address);
      if (connected) {
        setConnectedDevice(device);
        Alert.alert("Connected", `Connected to ${device.name || device.address}`);
      } else {
        Alert.alert("Connection Failed", "Could not connect to device.");
      }
    } catch (error) {
      Alert.alert("Connection Error", error.message);
    }
  };

  // ✅ Disconnect from device
  const disconnectFromDevice = async () => {
    try {
      if (connectedDevice) {
        await RNBluetoothClassic.disconnectFromDevice(connectedDevice.address);
        setConnectedDevice(null);
        Alert.alert("Disconnected", "Bluetooth device disconnected.");
      }
    } catch (error) {
      console.error("Disconnection Error:", error);
    }
  };

  // ✅ Send file via Bluetooth
  const sendFile = async () => {
    if (!connectedDevice) {
      Alert.alert("No Device Connected", "Please connect to a device first.");
      return;
    }

    try {
      // ✅ Open file picker
      const result = await DocumentPicker.getDocumentAsync({
        type: "*/*",
      });

      if (result.canceled || !result.assets || result.assets.length === 0) {
        console.log("User cancelled file picker");
        return;
      }

      const fileUri = result.assets[0].uri;
      const fileData = await FileSystem.readAsStringAsync(fileUri, {
        encoding: FileSystem.EncodingType.Base64,
      });

      // ✅ Send file data over Bluetooth in chunks
      const chunkSize = 1024;
      for (let i = 0; i < fileData.length; i += chunkSize) {
        const chunk = fileData.slice(i, i + chunkSize);
        await RNBluetoothClassic.writeToDevice(connectedDevice.address, chunk);

        // ✅ Small delay to prevent data loss
        await new Promise(r => setTimeout(r, 50));
        console.log(`📤 Sent chunk ${i / chunkSize + 1}`);
      }

      Alert.alert("Success", "File sent successfully!");
      disconnectFromDevice();
    } catch (error) {
      Alert.alert("Send Error", error.message);
    }
  };

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text style={{ fontSize: 20, marginBottom: 10 }}>Bluetooth File Transfer</Text>
      <FlatList
        data={pairedDevices}
        keyExtractor={(item) => item.address}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => connectToDevice(item)}>
            <Text style={{ padding: 10, borderBottomWidth: 1 }}>
              {item.name ? item.name : item.address}
            </Text>
          </TouchableOpacity>
        )}
      />
      {connectedDevice && (
        <View style={{ marginTop: 20 }}>
          <Text>Connected to: {connectedDevice.name || connectedDevice.address}</Text>
          <Button title="Send File" onPress={sendFile} />
          <Button title="Disconnect" onPress={disconnectFromDevice} color="red" />
        </View>
      )}
    </View>
  );
};


export default BluetoothSenderScreen;
