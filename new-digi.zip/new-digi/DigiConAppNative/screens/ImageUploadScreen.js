import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  Button,
  Image,
  StyleSheet,
  Alert,
  FlatList,
} from "react-native";
import * as ImagePicker from "react-native-image-picker";
import DocumentPicker from "react-native-document-picker";
import { uploadImage } from "../api";
import { saveImageOffline, uploadPendingImages } from "../utils/offlineStorage";
import NetInfo from "@react-native-community/netinfo";
import { checkStorageLimit } from "../utils/storageWarning";

const ImageUploadScreen = ({ route }) => {
  const [images, setImages] = useState([]);
  const containerId = route.params?.containerId || "1";

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener((state) => {
      if (state.isConnected) {
        console.log("📡 Network available! Uploading pending images...");
        uploadPendingImages();
      }
    });
    return () => unsubscribe();
  }, []);

  const takePicture = async () => {
    const hasStorage = await checkStorageLimit();
    if (!hasStorage) return;

    ImagePicker.launchCamera({ mediaType: "photo" }, (response) => {
      if (response.didCancel || !response.assets) return;

      if (images.length >= 12) {
        Alert.alert("Limit Reached", "You can only take up to 12 images per container.");
        return;
      }

      const newImages = response.assets.slice(0, 12 - images.length);
      setImages((prev) => [...prev, ...newImages]);
    });
  };

  const pickFromGallery = async () => {
    try {
      const result = await DocumentPicker.pickMultiple({
        type: [DocumentPicker.types.images],
      });

      if (images.length >= 12) {
        Alert.alert("Limit Reached", "You can only add up to 12 images per container.");
        return;
      }

      const remaining = 12 - images.length;
      const selected = result.slice(0, remaining).map((item) => ({
        uri: item.uri,
        type: item.type,
        fileName: item.name,
      }));

      setImages((prev) => [...prev, ...selected]);
    } catch (err) {
      if (!DocumentPicker.isCancel(err)) {
        Alert.alert("Error", "Failed to pick image(s) from gallery.");
      }
    }
  };

  const handleUpload = async () => {
    if (images.length === 0) {
      Alert.alert("Error", "Please capture or pick at least one image first.");
      return;
    }

    try {
      const netInfo = await NetInfo.fetch();

      for (const image of images) {
        const formData = new FormData();
        formData.append("image", {
          uri: image.uri,
          type: image.type || "image/jpeg",
          name: image.fileName || `photo_${Date.now()}.jpg`,
        });
        formData.append("container", containerId);

        if (!netInfo.isConnected) {
          await saveImageOffline(image.uri, containerId);
        } else {
          await uploadImage(formData);
        }
      }

      Alert.alert("Success", "Images uploaded successfully or saved offline.");
      setImages([]);
    } catch (error) {
      console.error("Upload error:", error);
      Alert.alert("Upload Failed", "Something went wrong while uploading images.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Capture & Upload Images</Text>

      <FlatList
        data={images}
        numColumns={3}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <Image source={{ uri: item.uri }} style={styles.image} />
        )}
      />

      <Button title="Take Picture" onPress={takePicture} />
      <View style={{ marginVertical: 10 }} />
      <Button title="Pick from Gallery" onPress={pickFromGallery} />
      <View style={{ marginVertical: 10 }} />
      <Button title="Upload" onPress={handleUpload} disabled={images.length === 0} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: "center", padding: 20 },
  title: { fontSize: 20, fontWeight: "bold", marginBottom: 10 },
  image: { width: 100, height: 100, margin: 5, borderRadius: 8 },
});

export default ImageUploadScreen
