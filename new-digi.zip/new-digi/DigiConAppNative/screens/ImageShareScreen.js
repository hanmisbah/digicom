import React, { useState } from 'react';
import { View, Text, Button, Image, Alert } from 'react-native';
import DocumentPicker from 'react-native-document-picker';
import Share from 'react-native-share';

const ImageShareScreen = () => {
    const [selectedImage, setSelectedImage] = useState(null);

    // Function to pick an image
    const pickImage = async () => {
        try {
            const result = await DocumentPicker.pickSingle({
                type: [DocumentPicker.types.images],
            });
            setSelectedImage(result);
        } catch (error) {
            if (DocumentPicker.isCancel(error)) {
                console.log("User canceled image picker");
            } else {
                Alert.alert("Error", error.message);
            }
        }
    };

    // Function to share via WhatsApp
    const shareViaWhatsApp = async () => {
        if (!selectedImage) {
            Alert.alert("No Image Selected", "Please select an image first.");
            return;
        }
        try {
            await Share.open({
                url: selectedImage.uri,
                social: Share.Social.WHATSAPP
            });
        } catch (error) {
            console.log("Sharing error:", error);
        }
    };

    // Function to share via Email
    const shareViaEmail = async () => {
        if (!selectedImage) {
            Alert.alert("No Image Selected", "Please select an image first.");
            return;
        }
        try {
            await Share.open({
                url: selectedImage.uri,
                subject: "Shared Image",
                email: "recipient@example.com",
                message: "Here is the image I wanted to share with you."
            });
        } catch (error) {
            console.log("Sharing error:", error);
        }
    };

    return (
        <View style={{ flex: 1, padding: 20, alignItems: 'center' }}>
            <Text style={{ fontSize: 20, marginBottom: 10 }}>Share Image</Text>
            {selectedImage && (
                <Image source={{ uri: selectedImage.uri }} style={{ width: 200, height: 200, marginBottom: 10 }} />
            )}
            <Button title="Pick an Image" onPress={pickImage} />
            <Button title="Share via WhatsApp" onPress={shareViaWhatsApp} />
            <Button title="Share via Email" onPress={shareViaEmail} />
        </View>
    );
};

export default ImageShareScreen;
