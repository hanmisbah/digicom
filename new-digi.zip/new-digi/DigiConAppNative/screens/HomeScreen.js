import React from "react";
import { View, Text, Button, FlatList, TouchableOpacity, StyleSheet } from "react-native";
import { useNavigation } from "@react-navigation/native";

const containers = [
  { id: "1", name: "Container 12345" },
  { id: "2", name: "Container 67890" },
];

const HomeScreen = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome to DigiConApp</Text>

      <FlatList
        data={containers}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.containerItem}
            onPress={() => navigation.navigate("ImageUpload", { containerId: item.id })}
          >
            <Text style={styles.containerText}>{item.name}</Text>
          </TouchableOpacity>
        )}
      />

      <Button title="Upload Image" onPress={() => navigation.navigate("ImageUpload")} />
      <Button title="Bluetooth Transfer" onPress={() => navigation.navigate("BluetoothScreen")} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#f8f8f8" },
  title: { fontSize: 24, fontWeight: "bold", marginBottom: 20, textAlign: "center" },
  containerItem: {
    padding: 15,
    backgroundColor: "#007BFF",
    borderRadius: 8,
    marginBottom: 10,
  },
  containerText: { color: "white", fontSize: 18 },
});

export default HomeScreen;
