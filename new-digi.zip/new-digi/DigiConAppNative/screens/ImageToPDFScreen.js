import React, { useState } from 'react';
import { View, Text, Button, Alert, Image } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { printToFileAsync } from 'expo-print';

const ImageToPDFScreen = () => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [pdfPath, setPdfPath] = useState(null);

  // 📸 Pick an Image from the Device
  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      quality: 1,
    });

    if (!result.canceled) {
      setSelectedImage(result.assets[0].uri);
    }
  };

  // 📝 Convert Image to PDF
  const convertToPDF = async () => {
    if (!selectedImage) {
      Alert.alert("No Image Selected", "Please select an image first.");
      return;
    }

    try {
      const htmlContent = `
        <html>
          <body style="text-align: center;">
            <img src="${selectedImage}" style="width:100%; max-width:600px;" />
          </body>
        </html>
      `;

      const { uri } = await printToFileAsync({
        html: htmlContent,
        base64: false,
      });

      setPdfPath(uri);
      Alert.alert("Success", "PDF created successfully!");
    } catch (error) {
      Alert.alert("Error", error.message);
    }
  };

  // 📤 Share PDF
  const sharePDF = async () => {
    if (!pdfPath) {
      Alert.alert("No PDF Found", "Convert an image to PDF first.");
      return;
    }

    if (!(await Sharing.isAvailableAsync())) {
      Alert.alert("Error", "Sharing is not available on this device.");
      return;
    }

    await Sharing.shareAsync(pdfPath);
  };

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text style={{ fontSize: 18, marginBottom: 10 }}>Image to PDF Converter</Text>
      <Button title="Select Image" onPress={pickImage} />
      {selectedImage && <Image source={{ uri: selectedImage }} style={{ width: 200, height: 200, margin: 10 }} />}
      <Button title="Convert to PDF" onPress={convertToPDF} />
      <Button title="Share PDF" onPress={sharePDF} disabled={!pdfPath} />
    </View>
  );
};

export default ImageToPDFScreen;

