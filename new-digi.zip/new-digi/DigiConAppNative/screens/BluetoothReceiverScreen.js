import React, { useState, useEffect, useRef } from 'react';
import { View, Text, Button, Alert, FlatList, PermissionsAndroid, Platform } from 'react-native';
import RNBluetoothClassic from 'react-native-bluetooth-classic';
import * as FileSystem from 'expo-file-system';

const BluetoothReceiverScreen = () => {
  const [serverStarted, setServerStarted] = useState(false);
  const [receivedFiles, setReceivedFiles] = useState([]);
  const serverRef = useRef(false);

  // ✅ Request Bluetooth permissions for Android
  useEffect(() => {
    const requestBluetoothPermission = async () => {
      if (Platform.OS === 'android') {
        try {
          const granted = await PermissionsAndroid.requestMultiple([
            PermissionsAndroid.PERMISSIONS.BLUETOOTH,
            PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
            PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
            PermissionsAndroid.PERMISSIONS.BLUETOOTH_ADVERTISE,
          ]);
          if (
            granted[PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT] !== PermissionsAndroid.RESULTS.GRANTED ||
            granted[PermissionsAndroid.PERMISSIONS.BLUETOOTH] !== PermissionsAndroid.RESULTS.GRANTED
          ) {
            Alert.alert("Permission Denied", "Bluetooth permissions are required.");
          }
        } catch (error) {
          console.error("Permission Error:", error);
        }
      }
    };
    requestBluetoothPermission();
  }, []);

  useEffect(() => {
    if (!serverStarted) {
      startBluetoothServer();
    }
  }, []);

  // ✅ Start Bluetooth server & wait for connections
  const startBluetoothServer = async () => {
    try {
      const isAvailable = await RNBluetoothClassic.isBluetoothAvailable();
      if (!isAvailable) {
        Alert.alert("Error", "Bluetooth is not available on this device.");
        return;
      }

      setServerStarted(true);
      serverRef.current = true;
      Alert.alert("Success", "Bluetooth receiver enabled. Waiting for incoming files...");

      while (serverRef.current) {
        const server = await RNBluetoothClassic.accept();
        listenForData(server);
      }

    } catch (error) {
      Alert.alert("Error", "Failed to start Bluetooth receiver: " + error.message);
    }
  };

  // ✅ Listen for incoming file data
  const listenForData = async (server) => {
    try {
      while (server.isConnected()) {
        const receivedData = await server.read(); // Read incoming data

        if (receivedData) {
          const filePath = FileSystem.documentDirectory + `received_file_${Date.now()}.txt`;
          await FileSystem.writeAsStringAsync(filePath, receivedData, { encoding: FileSystem.EncodingType.UTF8 });

          setReceivedFiles((prevFiles) => [...prevFiles, filePath]);
          Alert.alert("Success", "📂 File received and saved.");
        }
      }
    } catch (error) {
      console.error("Receiving Error:", error);
      Alert.alert("Receiving Error", error.message);
    }
  };

  // ✅ Stop Bluetooth server
  const stopBluetoothServer = () => {
    serverRef.current = false;
    setServerStarted(false);
  };

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text style={{ fontSize: 20, marginBottom: 10 }}>Bluetooth Receiver</Text>
      <Button title="Start Receiving" onPress={startBluetoothServer} disabled={serverStarted} />
      <Button title="Stop Receiving" onPress={stopBluetoothServer} disabled={!serverStarted} />
      <FlatList
        data={receivedFiles}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => <Text>{item}</Text>}
      />
    </View>
  );
};

export default BluetoothReceiverScreen;

