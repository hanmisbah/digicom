import React from 'react';
import { View, Text, Button, Alert } from 'react-native';
import * as FileSystem from 'expo-file-system';

const FileSharingScreen = () => {
  const shareFile = async () => {
    try {
      const fileUri = `${FileSystem.documentDirectory}received_file.txt`;

      // Check if file exists
      const fileInfo = await FileSystem.getInfoAsync(fileUri);
      if (!fileInfo.exists) {
        Alert.alert("Error", "File not found!");
        return;
      }

      // Dynamically import expo-sharing to prevent errors on unsupported devices
      const Sharing = await import('expo-sharing');
      const isAvailable = await Sharing.isAvailableAsync();
      
      if (!isAvailable) {
        Alert.alert("Error", "Sharing is not supported on this device");
        return;
      }

      await Sharing.shareAsync(fileUri);
    } catch (error) {
      Alert.alert("Error", "Failed to share file: " + error.message);
    }
  };

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text style={{ fontSize: 20, marginBottom: 10 }}>File Sharing</Text>
      <Button title="Share File" onPress={shareFile} />
    </View>
  );
};

export default FileSharingScreen;

